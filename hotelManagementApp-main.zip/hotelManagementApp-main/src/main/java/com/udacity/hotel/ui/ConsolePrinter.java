package com.udacity.hotel.ui;


public interface ConsolePrinter {


    <T> void print(T text);
}
