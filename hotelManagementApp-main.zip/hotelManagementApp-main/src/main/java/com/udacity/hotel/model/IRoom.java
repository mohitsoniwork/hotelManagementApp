package com.udacity.hotel.model;


public interface IRoom {
    String getRoomNumber();
}
