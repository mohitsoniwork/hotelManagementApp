package com.udacity.hotel.model;


public enum RoomType {
    SINGLE,
    DOUBLE
}
