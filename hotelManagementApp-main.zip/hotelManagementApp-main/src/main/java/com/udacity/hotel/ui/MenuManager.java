package com.udacity.hotel.ui;


public interface MenuManager {
    void open();
}
